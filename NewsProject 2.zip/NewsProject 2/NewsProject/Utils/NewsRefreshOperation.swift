//
//  NewsRefreshOperation.swift
//  NewsProject
//
//  Created by Bushara Siddiqui on 04/05/25.
//

import Foundation
class NewsRefreshOperation: Operation {
    override func main() {
        guard !isCancelled else { return }
        
        let semaphore = DispatchSemaphore(value: 0)
        
        NewsService().fetchTopHeadlines { articles in
            // Save or process articles
            print("Background fetch: \(articles.count) articles updated.")
            semaphore.signal()
        }
        
        semaphore.wait()
    }
}
