//
//  UtilManager.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//

import Foundation
import UIKit

class UtilManager: NSObject {
    static let sharedManager = UtilManager()
    public let TabBarController:UIStoryboard = {
        return UIStoryboard(name: "Main", bundle: nil)
    }()
    func setLoginVCAsLandingPage(){
        let loginNavVC:UINavigationController  =  UIStoryboard(name: "LaunchScreenViewController", bundle: nil).instantiateViewController(withIdentifier: "launchAnimation") as! UINavigationController
        loginNavVC.navigationBar.isHidden = true
        if #available(iOS 13.0, *) {
            guard let scene = UIApplication.shared.connectedScenes.first,
                  let windowSceneDelegate = scene.delegate as? UIWindowSceneDelegate,
                  let windowScene = windowSceneDelegate.window else {
                return
            }
            windowScene!.rootViewController = loginNavVC
        }else{
            if let delegate = UIApplication.shared.delegate as? AppDelegate{
                delegate.window?.rootViewController = loginNavVC
            }
        }
    }
}
