//
//  LaunchScreenViewController.swift
//  Bringin
//
//  Created by  Bushara Siddiqui on 03/05/25.
//

import UIKit
import AVKit

class LaunchScreenViewController: UIViewController {
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var isVideoReadyToPlay = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .clear
        guard let videoURL = Bundle.main.url(forResource: "News1", withExtension: "mp4") else {
            fatalError("Video file not found")
        }
        view.backgroundColor = .systemBackground
        player = AVPlayer(url: videoURL)
        player?.currentItem?.preferredForwardBufferDuration = 5
        player?.currentItem?.addObserver(self, forKeyPath: #keyPath(AVPlayerItem.status), options: [.old, .new], context: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(videoDidFinishPlaying), name: .AVPlayerItemDidPlayToEndTime, object: player?.currentItem)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if isVideoReadyToPlay {
            player?.play()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player?.pause()
    }
    
    deinit {
        player?.currentItem?.removeObserver(self, forKeyPath: #keyPath(AVPlayerItem.status))
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: player?.currentItem)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let item = object as? AVPlayerItem, keyPath == #keyPath(AVPlayerItem.status) else {
            return
        }
        if item.status == .readyToPlay {
            isVideoReadyToPlay = true
            playerLayer = AVPlayerLayer(player: player)
            playerLayer?.videoGravity = .resizeAspectFill
            if let playerLayer = playerLayer {
                view.layer.insertSublayer(playerLayer, at: 0)
            }
            playerLayer?.frame = view.bounds
            player?.play()
        }
    }
    
    // Handle video playback completion
    @objc private func videoDidFinishPlaying() {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.setupRoot()
        }
    }
    
}
