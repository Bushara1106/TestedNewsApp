//
//  NewsResponse.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//

import Foundation

struct NewsResponse: Codable {
    let articles: [Article]
}

struct Article: Codable {
    let title: String
    let description: String?
    let urlToImage: String?
    let content: String?
}


