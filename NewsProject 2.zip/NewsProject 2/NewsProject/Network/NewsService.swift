//
//  NewsService.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//
import Foundation
import Alamofire

class NewsService {
    static let shared = NewsService()
    let apiKey = "d46e73159fbf4a5fb96e80c3060756b9"
    
    func fetchTopHeadlines(page: Int = 1, completion: @escaping ([Article]) -> Void) {
        let url = "https://newsapi.org/v2/top-headlines"
        let parameters: Parameters = [
            "country": "us",
            "apiKey": apiKey,
            "page": page,
            "pageSize": 10
        ]
        
        AF.request(url, parameters: parameters).responseDecodable(of: NewsResponse.self) { response in
            switch response.result {
            case .success(let newsResponse):
                completion(newsResponse.articles)
            case .failure(let error):
                print("❌ Failed to fetch news:", error)
                completion([])
            }
        }
    }
    
    // ✅ Add this inside the class
    func searchArticles(query: String, completion: @escaping ([Article]) -> Void) {
        let url = "https://newsapi.org/v2/everything"
        let parameters: Parameters = [
            "q": query,
            "apiKey": apiKey,
            "pageSize": 20
        ]
        
        AF.request(url, parameters: parameters).responseDecodable(of: NewsResponse.self) { response in
            switch response.result {
            case .success(let newsResponse):
                completion(newsResponse.articles)
            case .failure(let error):
                print("❌ Failed to search news:", error)
                completion([])
            }
        }
    }
    
    func getAllArticles(completion: @escaping ([Article]) -> Void) {
           // Call your API for top/trending/all news here
           // Simulated example:
           AF.request("https://api.example.com/news/all").responseDecodable(of: [Article].self) { response in
               switch response.result {
               case .success(let articles):
                   completion(articles)
               case .failure:
                   completion([]) // Return empty on failure
               }
           }
       }
}
