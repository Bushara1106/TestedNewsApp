//
//  LoginViewController.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//

import UIKit
import GoogleSignIn
import FirebaseAuth
import FirebaseCore


class LoginViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupGoogleSignInButton()
        view.backgroundColor = .systemBackground
        
        
    }
    
    private func setupGoogleSignInButton() {
        let signInButton = UIButton(type: .system)
        signInButton.setTitle("Sign in with Google", for: .normal)
        signInButton.addTarget(self, action: #selector(handleSignIn), for: .touchUpInside)
        signInButton.center = view.center
        signInButton.frame = CGRect(x: 0, y: 0, width: 200, height: 50)
        signInButton.center = view.center
        view.addSubview(signInButton)
    }
    
    @objc private func handleSignIn() {
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        GIDSignIn.sharedInstance.signIn(withPresenting: self) { result, error in
            if let error = error {
                print("Google Sign-In error:", error.localizedDescription)
                
                return
            }
            
            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString else {
                print("Missing Google ID token")
                return
            }
            
            let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                           accessToken: user.accessToken.tokenString)
            
            Auth.auth().signIn(with: credential) { authResult, error in
                if let error = error {
                    print("Firebase sign-in failed:", error.localizedDescription)
                    return
                }
                self.fetchAndStoreUserProfile(user: user)
            }
        }
    }
    func fetchAndStoreUserProfile(user: GIDGoogleUser) {
        // Fetch user info
        let name = user.profile?.name
        let email = user.profile?.email
        let profilePictureURL = user.profile?.imageURL(withDimension: 200)
        
        // Store user info in UserDefaults (or use CoreData)
        UserDefaults.standard.set(name, forKey: "userName")
        UserDefaults.standard.set(email, forKey: "userEmail")
        UserDefaults.standard.set(profilePictureURL?.absoluteString, forKey: "userProfilePictureURL")
        
        // Navigate to HomeViewController
        self.navigateToHomeViewController()
    }
    
    func navigateToHomeViewController() {
        let mainTabVC: TabBarViewController = UtilManager.sharedManager.TabBarController.instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
        mainTabVC.selectedIndex = 0

        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let sceneDelegate = windowScene.delegate as? SceneDelegate,
           let window = sceneDelegate.window {
            window.rootViewController = mainTabVC
            window.makeKeyAndVisible()
        } else {
            print("⚠️ Could not get SceneDelegate or window.")
        }
    }

}
