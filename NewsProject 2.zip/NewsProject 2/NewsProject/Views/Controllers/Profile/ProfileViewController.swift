//
//  ProfileViewController.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//
import UIKit
import CoreLocation
import AVFoundation
import Photos


class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var latitudeLabel: UILabel!
    @IBOutlet weak var longitudeLabel: UILabel!
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadProfileInfo()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        view.backgroundColor = .systemBackground
        // Start updating location explicitly
        locationManager.requestLocation()
        checkLocationAuthorizationStatus()
        
    }
    @available(iOS 14.0, *)
    func checkLocationAuthorizationStatus() {
        let status = locationManager.authorizationStatus
        handleAuthorizationStatus(status)
    }
    func handleAuthorizationStatus(_ status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            locationManager.requestLocation()
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .denied, .restricted:
            showAlertToEnableLocationServices()
        @unknown default:
            break
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        profileImageView.layer.cornerRadius = profileImageView.frame.height / 2
        profileImageView.clipsToBounds = true
    }
    
    // MARK: - Display Google Profile Info
    func loadProfileInfo() {
        let name = UserDefaults.standard.string(forKey: "userName") ?? "Guest"
        let email = UserDefaults.standard.string(forKey: "userEmail") ?? "No Email"
        let profileImageURLString = UserDefaults.standard.string(forKey: "userProfilePictureURL")
        
        nameLabel.text = name
        emailLabel.text = email
        
        if let profileImageURLString = profileImageURLString, let profileImageURL = URL(string: profileImageURLString) {
            profileImageView.loadImage(from: profileImageURL)
        } else {
            profileImageView.image = UIImage(named: "defaultProfileImage")
        }
    }
    
    // MARK: - Display Current Location
    
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status: CLAuthorizationStatus
        
        if #available(iOS 14.0, *) {
            status = manager.authorizationStatus
        } else {
            status = CLLocationManager.authorizationStatus()
        }
        
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            locationManager.startUpdatingLocation()
        case .denied, .restricted:
            print("Location access denied or restricted.")
            showAlertToEnableLocationServices()
        case .notDetermined:
            break
        @unknown default:
            break
        }
    }
    
    
    
    func showAlertToEnableLocationServices() {
        let alert = UIAlertController(title: "Location Access Denied", message: "Please enable location services in Settings.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to get location: \(error.localizedDescription)")
        
        if let clError = error as? CLError {
            switch clError.code {
            case .denied:
                print("Location services are denied.")
            case .locationUnknown:
                print("Location unknown. Location services may be temporarily unavailable.")
            default:
                print("Other error: \(clError)")
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        let latitude = location.coordinate.latitude
        let longitude = location.coordinate.longitude
        DispatchQueue.main.async {
            self.latitudeLabel.text = "Latitude: \(latitude)"
            self.longitudeLabel.text = "Longitude: \(longitude)"
        }
        locationManager.stopUpdatingLocation()
    }
    
    
    
    
    
    // MARK: - Allow Profile Photo Update (Camera or Gallery)
    @IBAction func changeProfileImageTapped(_ sender: UIButton) {
        showImagePickerOptions()
    }
    
    func showImagePickerOptions() {
        let alertController = UIAlertController(title: "Select Photo", message: nil, preferredStyle: .actionSheet)
        
        alertController.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.presentImagePicker(sourceType: .camera)
        }))
        
        alertController.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.presentImagePicker(sourceType: .photoLibrary)
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        present(alertController, animated: true, completion: nil)
    }
    
    func presentImagePicker(sourceType: UIImagePickerController.SourceType) {
        switch sourceType {
        case .camera:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    if granted {
                        self.showImagePicker(sourceType: .camera)
                    } else {
                        self.showPermissionAlert(for: "Camera")
                    }
                }
            }
        case .photoLibrary:
            PHPhotoLibrary.requestAuthorization { status in
                DispatchQueue.main.async {
                    if status == .authorized || status == .limited {
                        self.showImagePicker(sourceType: .photoLibrary)
                    } else {
                        self.showPermissionAlert(for: "Photo Library")
                    }
                }
            }
        default:
            break
        }
    }
    func showImagePicker(sourceType: UIImagePickerController.SourceType) {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = sourceType
        imagePicker.delegate = self
        present(imagePicker, animated: true)
    }

    func showPermissionAlert(for source: String) {
        let alert = UIAlertController(title: "\(source) Access Denied", message: "Please enable access in Settings.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Open Settings", style: .default, handler: { _ in
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsURL)
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }
    
    // MARK: - UIImagePickerController Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            saveProfileImage(selectedImage)
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - Save Profile Image
    func saveProfileImage(_ image: UIImage) {
        if let imageData = image.jpegData(compressionQuality: 0.8) {
            let fileManager = FileManager.default
            do {
                let documentsDirectory = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                let fileURL = documentsDirectory.appendingPathComponent("profileImage.jpg")
                try imageData.write(to: fileURL)
                UserDefaults.standard.set(fileURL.absoluteString, forKey: "userProfilePictureURL")
                profileImageView.image = image
            } catch {
                print("Error saving image: \(error)")
            }
        }
    }
    
    
    
}
extension UIImageView {
    func loadImage(from url: URL) {
        DispatchQueue.global().async {
            guard let data = try? Data(contentsOf: url),
                  let image = UIImage(data: data) else {
                print("Failed to load image from URL: \(url)")
                return
            }
            
            DispatchQueue.main.async {
                self.image = image
            }
        }
    }
}
