//
//  HomeViewController.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//

import UIKit

class HomeViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {
    var isFetching = false
    var articles: [Article] = []
    var currentPage = 1
    let newsService = NewsService()
    var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "News"
        view.backgroundColor = .white
        setupCollectionView()
        setupRefreshControl()
        fetchArticles()
        view.backgroundColor = .systemBackground
      
    }
    override func viewWillAppear(_ animated: Bool) {
        setupProfileButton()
    }
    func setupRefreshControl() {
           let refreshControl = UIRefreshControl()
           refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
           collectionView.refreshControl = refreshControl
       }
    func setupProfileButton() {
            let profileImageView = UIImageView()
            profileImageView.contentMode = .scaleAspectFill
            profileImageView.layer.cornerRadius = 18
            profileImageView.clipsToBounds = true
            profileImageView.frame = CGRect(x: 0, y: 0, width: 36, height: 36)

            if let urlString = UserDefaults.standard.string(forKey: "userProfilePictureURL"),
               let url = URL(string: urlString) {

                if url.isFileURL {
                    // Load from local file
                    if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
                        profileImageView.image = image
                    } else {
                        profileImageView.image = UIImage(systemName: "person.crop.circle")
                    }
                } else {
                    // Load from remote URL
                    URLSession.shared.dataTask(with: url) { data, _, error in
                        if let data = data, let image = UIImage(data: data), error == nil {
                            DispatchQueue.main.async {
                                profileImageView.image = image
                            }
                        } else {
                            DispatchQueue.main.async {
                                profileImageView.image = UIImage(systemName: "person.crop.circle")
                            }
                        }
                    }.resume()
                }
            } else {
                profileImageView.image = UIImage(systemName: "person.crop.circle")
            }

            let containerView = UIView(frame: profileImageView.frame)
            containerView.addSubview(profileImageView)

            let barButtonItem = UIBarButtonItem(customView: containerView)
            navigationItem.rightBarButtonItem = barButtonItem
        }
    @objc func refreshData() {
        articles.removeAll()
        currentPage = 1
        fetchArticles(page: currentPage)
        collectionView.refreshControl?.endRefreshing()
    }
    
    func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 0
        
        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: layout)
        collectionView.isPagingEnabled = true
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.showsVerticalScrollIndicator = false
        collectionView.register(NewsCell.self, forCellWithReuseIdentifier: "NewsCell")
        collectionView.backgroundColor = .white
        
        view.addSubview(collectionView)
    }
    
    //    func fetchArticles(page: Int = 1) {
    //        newsService.fetchTopHeadlines(page: page) { [weak self] fetchedArticles in
    //            guard let self = self else { return }
    //            self.articles.append(contentsOf: fetchedArticles)
    //            DispatchQueue.main.async {
    //                self.collectionView.reloadData()
    //            }
    //        }
    //    }
    func fetchArticles(page: Int = 1) {
        isFetching = true
        let cachedArticles = CoreDataManager.shared.fetchArticles()
        if cachedArticles.isEmpty {
            // No cached articles, fetch from API
            newsService.fetchTopHeadlines(page: page) { [weak self] fetchedArticles in
                guard let self = self else { return }
                self.articles.append(contentsOf: fetchedArticles)
                
                // Cache fetched articles to Core Data
                for article in fetchedArticles {
                    CoreDataManager.shared.insertArticle(title: article.title, descriptionText: article.description ?? "", url: article.urlToImage ?? "")
                }
                
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                    self.collectionView.refreshControl?.endRefreshing()
                                      self.isFetching = false
                }
            }
        } else {
            // Map cached Core Data objects to your Article model
            let mappedArticles: [Article] = cachedArticles.map { articleDetail in
                return Article(
                    title: articleDetail.title ?? "",
                    description: articleDetail.descriptionText,
                    urlToImage: articleDetail.urlToImage,
                    content: articleDetail.content
                )
            }
            self.articles = mappedArticles
            
            DispatchQueue.main.async {
                self.collectionView.reloadData()
                self.collectionView.refreshControl?.endRefreshing()
                               self.isFetching = false
            }
        }
        
    }
    
    // MARK: - UICollectionView DataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return articles.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let article = articles[indexPath.item]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NewsCell", for: indexPath) as! NewsCell
        cell.configure(with: article)
        
        // Adding swipe gesture recognizers
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleLeftSwipe(_:)))
        leftSwipe.direction = .left
        cell.addGestureRecognizer(leftSwipe)
        
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleRightSwipe(_:)))
        rightSwipe.direction = .right
        cell.addGestureRecognizer(rightSwipe)
        
        return cell
    }
    
    // MARK: - Swipe Gesture Handlers
    
    @objc func handleLeftSwipe(_ gesture: UISwipeGestureRecognizer) {
        guard let cell = gesture.view as? NewsCell,
              let indexPath = collectionView.indexPath(for: cell) else { return }
        
        print("Left swipe detected for article: \(articles[indexPath.item].title)")
        
        // Animate the cell sliding out to the left
        UIView.animate(withDuration: 0.3, animations: {
            cell.transform = CGAffineTransform(translationX: -cell.frame.width, y: 0)
            cell.alpha = 0.0
        }, completion: { _ in
            self.articles.remove(at: indexPath.item)
            self.collectionView.performBatchUpdates({
                self.collectionView.deleteItems(at: [indexPath])
            }, completion: nil)
        })
    }
    
    @objc func handleRightSwipe(_ gesture: UISwipeGestureRecognizer) {
        guard let cell = gesture.view as? NewsCell,
              let indexPath = collectionView.indexPath(for: cell) else { return }
        
        let selectedArticle = articles[indexPath.item]
        print("Right swipe detected for article: \(selectedArticle.title)")
        
        let detailVC = ArticleDetailViewController()
        detailVC.article = selectedArticle
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
    
    // MARK: - UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.frame.size
    }
    func collectionView(_ collectionView: UICollectionView,
                        trailingSwipeActionsConfigurationForItemAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [weak self] (action, view, completionHandler) in
            guard let self = self else { return }
            UIView.animate(withDuration: 0.3, animations: {
                view.alpha = 0.0
            }) { _ in
                self.articles.remove(at: indexPath.item)
                collectionView.deleteItems(at: [indexPath])
                completionHandler(true)
            }
        }
        let config = UISwipeActionsConfiguration(actions: [deleteAction])
        config.performsFirstActionWithFullSwipe = true
        return config
    }
    
    // Right Swipe Action - Open Details
    func collectionView(_ collectionView: UICollectionView,
                        leadingSwipeActionsConfigurationForItemAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let detailsAction = UIContextualAction(style: .normal, title: "Details") { (action, view, completionHandler) in
            // Handle opening details
            print("Open details for article: \(self.articles[indexPath.item].title)")
            completionHandler(true)
        }
        
        detailsAction.backgroundColor = .systemBlue
        let config = UISwipeActionsConfiguration(actions: [detailsAction])
        return config
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
           let offsetY = scrollView.contentOffset.y
           let contentHeight = scrollView.contentSize.height
           let height = scrollView.frame.size.height

           if offsetY > contentHeight - height * 1.5 && !isFetching {
               currentPage += 1
               fetchArticles(page: currentPage)
           }
       }
}
