//
//  SplashViewController.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//
import UIKit
import AVKit
import FirebaseAuth

class SplashViewController: UIViewController {
    var window: UIWindow?
    var player: AVPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playSplashVideo()
    }
    
    func playSplashVideo() {
        guard let path = Bundle.main.path(forResource: "splash", ofType:"mp4") else {
            navigateToLogin()
            return
        }
        
        player = AVPlayer(url: URL(fileURLWithPath: path))
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = view.bounds
        view.layer.addSublayer(playerLayer)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(videoDidFinish),
                                               name: .AVPlayerItemDidPlayToEndTime,
                                               object: player?.currentItem)
        
        player?.play()
    }
    
    @objc func videoDidFinish() {
        navigateToLogin()
    }
    
    func navigateToLogin() {
      
    }
}
