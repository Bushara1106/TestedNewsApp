//
//  SearchViewController.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//
import UIKit
import Alamofire
import SkeletonView

class SearchViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate {
    
    var articles: [Article] = []
    var collectionView: UICollectionView!
    let searchBar = UISearchBar()
    let newsService = NewsService()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Search"
        setupSearchBar()
        setupCollectionView()
        view.backgroundColor = .systemBackground
        loadAllArticles()
    }
    
    func setupSearchBar() {
        searchBar.delegate = self
        searchBar.placeholder = "Search for news"
        navigationItem.titleView = searchBar
    }
    func loadAllArticles() {
        collectionView.showAnimatedGradientSkeleton()

        newsService.fetchTopHeadlines { [weak self] results in
            guard let self = self else { return }
            self.articles = results

            DispatchQueue.main.async {
                self.collectionView.stopSkeletonAnimation()
                self.view.hideSkeleton()
                self.collectionView.reloadData()
            }
        }
    }

    func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        
        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: layout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(NewsCell.self, forCellWithReuseIdentifier: "NewsCell")
        collectionView.backgroundColor = .white
        collectionView.isSkeletonable = true
        view.isSkeletonable = true
        
        view.addSubview(collectionView)
        collectionView.showAnimatedGradientSkeleton()
        
        // Simulate data load
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.collectionView.stopSkeletonAnimation()
            self.view.hideSkeleton()
            self.collectionView.reloadData()
        }
    }
    
    // MARK: - UICollectionView DataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return articles.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NewsCell", for: indexPath) as! NewsCell
        cell.configure(with: articles[indexPath.item])
        return cell
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding: CGFloat = 10
        let availableWidth = collectionView.frame.width - (padding * 3)
        let width = availableWidth / 2
        return CGSize(width: width, height: width * 1.4)
    }
    
    // MARK: - UISearchBarDelegate
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        guard let query = searchBar.text, !query.isEmpty else { return }
        
        // Start shimmer before API call
        collectionView.showAnimatedGradientSkeleton()
        
        newsService.searchArticles(query: query) { [weak self] results in
            guard let self = self else { return }
            self.articles = results
            
            DispatchQueue.main.async {
                self.collectionView.stopSkeletonAnimation()
                self.view.hideSkeleton()
                self.collectionView.reloadData()
            }
        }
    }
    
    
}
