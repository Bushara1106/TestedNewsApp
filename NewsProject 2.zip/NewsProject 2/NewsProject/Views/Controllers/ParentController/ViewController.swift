//
//  ViewController.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

