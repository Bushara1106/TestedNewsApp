//
//  TabBarViewController.swift
//  NewsAppProject
//
//  Created by Bushara Siddiqui on 03/05/25.
//
import UIKit

class TabBarViewController: UITabBarController,UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBar.barTintColor = .clear
        self.tabBar.backgroundColor = .clear
        let tabBarHeight = self.tabBar.bounds.height
        let tabBarWidth = self.tabBar.bounds.width
        let tabBarY = self.tabBar.bounds.minY
        let cornerRadius = tabBarHeight / 2
        let shadowLayerRect = CGRect(x: 30 , y: tabBarY , width: tabBarWidth - 60, height: tabBarHeight)
        view.backgroundColor = .systemBackground
        let layer = CAShapeLayer()
        layer.path = UIBezierPath(roundedRect: shadowLayerRect, cornerRadius: cornerRadius).cgPath
        layer.shadowColor = UIColor.lightGray.cgColor
        layer.shadowOffset = CGSize(width: 5.0, height: 5.0)
        layer.shadowRadius = 25.0
        layer.shadowOpacity = 0.3
        layer.borderWidth = 1.0
        layer.opacity = 1.0
        layer.isHidden = false
        layer.masksToBounds = false
        layer.fillColor = UIColor.white.cgColor
        
        self.tabBar.layer.insertSublayer(layer, at: 0)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        if let items = self.tabBar.items {
            items.forEach { item in item.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0) }
        }
        
        self.tabBar.itemWidth = 35.0
        self.tabBar.itemPositioning = .centered
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(true)
    }
   
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if tabBar.items?[0] == item{
            NotificationCenter.default.post(name: .scrollTableViewToTop, object: nil)
        }else{
            
        }
        
        print("Selected item")
    }
    
    // UITabBarControllerDelegate
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        print("Selected view controller")
    }
    
}
extension TabBarViewController {
    @objc func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        switch gesture.direction {
        case .right:
            if selectedIndex > 0 {
                selectedIndex -= 1
            }
        case .left:
            
            if selectedIndex < (viewControllers?.count ?? 0) - 1 {
                selectedIndex += 1
            }
        default:
            break
        }
    }
}

extension Notification.Name {
    static let scrollTableViewToTop = Notification.Name("ScrollTableviewToTop")
}
