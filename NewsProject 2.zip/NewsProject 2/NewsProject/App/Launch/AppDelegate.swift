//
//  AppDelegate.swift
//  News
//
//  Created by Bushara Siddiqui on 03/05/25.
//

import UIKit
import Firebase
import GoogleSignIn
import BackgroundTasks
import FirebaseMessaging

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var refreshTimer: Timer?
    
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        FirebaseApp.configure()
        
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.makeKeyAndVisible()
        //        registerBackgroundTasks()
        registerForPushNotifications(application: application)
        scheduleTimerForBackgroundRefresh()
        
        return true
    }
    func registerForPushNotifications(application: UIApplication) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { (granted, error) in
            if granted {
                DispatchQueue.main.async {
                    application.registerForRemoteNotifications()
                }
            }
        }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        // Send deviceToken to Firebase for FCM
        Messaging.messaging().apnsToken = deviceToken
    }
    
    // Handle silent push notifications
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        guard let content = userInfo["content"] as? [String: Any],
              let shouldFetch = content["shouldFetch"] as? Bool, shouldFetch else {
            completionHandler(.noData)
            return
        }
        
        // Trigger the news fetch on receiving silent push
        refreshNews()
        completionHandler(.newData)
    }
    
    // MARK: - Schedule Timer for News Refresh every 30 minutes
    func scheduleTimerForBackgroundRefresh() {
        refreshTimer = Timer.scheduledTimer(timeInterval: 30 * 60, target: self, selector: #selector(refreshNews), userInfo: nil, repeats: true)
    }
    @objc func refreshNews() {
        NewsService().fetchTopHeadlines{ articles in
            print("News refreshed via timer: \(articles.count) articles")
        }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        refreshTimer?.invalidate()
    }
    func launchScreen(){
        let loginNavVC:UINavigationController  =  UIStoryboard(name: "LaunchScreenViewController", bundle: nil).instantiateViewController(withIdentifier: "launchAnimation") as! UINavigationController
        loginNavVC.navigationBar.isHidden = true
        window?.rootViewController = loginNavVC
        window?.makeKeyAndVisible()
    }
    // MARK: UISceneSession Lifecycle
    func registerBackgroundTasks() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: "com.yourapp.newsrefresh", using: nil) { task in
            self.handleAppRefresh(task: task as! BGAppRefreshTask)
        }
        
        scheduleAppRefresh()
    }
    
    // MARK: - Schedule App Refresh
    func scheduleAppRefresh() {
        let request = BGAppRefreshTaskRequest(identifier: "com.yourapp.newsrefresh")
        request.earliestBeginDate = Date(timeIntervalSinceNow: 30 * 60) // every 30 minutes
        
        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            print("Could not schedule app refresh: \(error)")
        }
    }
    // MARK: - Handle Task
    func handleAppRefresh(task: BGAppRefreshTask) {
        scheduleAppRefresh() // Reschedule
        
        let queue = OperationQueue()
        queue.maxConcurrentOperationCount = 1
        
        let operation = NewsRefreshOperation()
        task.expirationHandler = {
            queue.cancelAllOperations()
        }
        
        operation.completionBlock = {
            task.setTaskCompleted(success: !operation.isCancelled)
        }
        
        queue.addOperation(operation)
    }
    func setupRoot() {
        let isLoggedIn = Auth.auth().currentUser != nil
        
        let rootVC: UIViewController
        if isLoggedIn {
            let mainTabVC: TabBarViewController = UtilManager.sharedManager.TabBarController.instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
            
            for scene in UIApplication.shared.connectedScenes {
                if scene.activationState == .foregroundActive {
                }
                guard let window = ((scene as? UIWindowScene)!.delegate as! UIWindowSceneDelegate).window else { fatalError() }
                window!.rootViewController = mainTabVC
                break
            }
            mainTabVC.selectedIndex = 0
            
        } else {
            // If not logged in, show the login screen
            rootVC = LoginViewController()
            let navController = UINavigationController(rootViewController: rootVC)
            navController.modalTransitionStyle = .crossDissolve
            window?.rootViewController = navController
            window?.makeKeyAndVisible()
        }
    }
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        
    }
    @available(iOS 9.0, *)
    func application(_ app: UIApplication, open url: URL,
                     options: [UIApplication.OpenURLOptionsKey : Any]) -> Bool {
        return GIDSignIn.sharedInstance.handle(url)
    }
    
}

import AVKit

extension AppDelegate {
    func playSplashVideo() {
        guard let path = Bundle.main.path(forResource: "splash", ofType:"mp4") else {
            
            return
        }
        
        let player = AVPlayer(url: URL(fileURLWithPath: path))
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        playerViewController.showsPlaybackControls = false
        
        window?.rootViewController = playerViewController
        window?.makeKeyAndVisible()
        
        NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime,
                                               object: player.currentItem, queue: .main) { [weak self] _ in
            self?.setupRoot()
        }
        
        player.play()
    }
}
