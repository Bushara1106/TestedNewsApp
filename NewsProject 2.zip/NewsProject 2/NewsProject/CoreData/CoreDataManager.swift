//
//  CoreDataManager.swift
//  NewsProject
//
//  Created by Bushara Siddiqui on 04/05/25.
//
import Foundation
import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()
    
    private init() {}
    
    var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "NewsApp")
        container.loadPersistentStores { storeDescription, error in
            if let error = error {
                fatalError("Unable to load persistent stores: \(error)")
            }
        }
        return container
    }()
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    // Save context
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
    
    // Insert a new article
    func insertArticle(title: String, descriptionText: String, url: String) {
        let article = ArticleDetails(context: context)
        article.title = title
        article.descriptionText = descriptionText
        article.urlToImage = url
        saveContext()
    }
    
    // Fetch all articles
    func fetchArticles() -> [ArticleDetails] {
        let fetchRequest: NSFetchRequest<ArticleDetails> = ArticleDetails.fetchRequest()
        do {
            return try context.fetch(fetchRequest)
        } catch {
            print("Failed to fetch articles: \(error)")
            return []
        }
    }
}
